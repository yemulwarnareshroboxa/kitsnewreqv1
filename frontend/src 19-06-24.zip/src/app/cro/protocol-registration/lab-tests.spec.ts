import { LabTests } from './lab-tests';

describe('LabTests', () => {
  it('should create an instance', () => {
    expect(new LabTests()).toBeTruthy();
  });
});
