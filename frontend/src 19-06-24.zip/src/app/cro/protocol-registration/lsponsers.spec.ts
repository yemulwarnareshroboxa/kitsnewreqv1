import { LSponsers } from './lsponsers';

describe('LSponsers', () => {
  it('should create an instance', () => {
    expect(new LSponsers()).toBeTruthy();
  });
});
