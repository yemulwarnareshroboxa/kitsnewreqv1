export class LabTests {
    "created_by": number
    "size": string
    "lab_code": string
    "user_id": number
    "material": string
    "changed_on": string
    "lab_id": string
    "image": string;
    "created_on": string;
    "lab_test": string;
    "changed_by": number
}
