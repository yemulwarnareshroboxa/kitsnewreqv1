import { CROS } from './cros';

describe('CROS', () => {
  it('should create an instance', () => {
    expect(new CROS()).toBeTruthy();
  });
});
