import { InstructionsAppDirective } from './instructions-app.directive';

describe('InstructionsAppDirective', () => {
  it('should create an instance', () => {
    const directive = new InstructionsAppDirective();
    expect(directive).toBeTruthy();
  });
});
