export class Sites {
    "address_4": string;
    "address_1": string;
    "site_data_name": string;
    "changed_on": string;
    "country": string
    "zip_code": string;
    "changed_by": number;
    "site_id": string;
    "site_data_code": string;
    "email": string
    "region": string;
    "city": string;
    "mobile_telephone": string;
    "address_3": string;
    "address_2": string;
    "legal_site_data_name": string;
    "created_by": string;
    "user_id": string;
    "office_telephone": string;
    "created_on": string;
    "website": string;
    "district": string;
    "extension": string
}
