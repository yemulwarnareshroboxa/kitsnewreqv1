export class LSponsers {
    "address_4" : string;
    "address_1": string;
    "changed_on": string;
    "legal_sponsor_name": string;
    "country": string;
    "zip_code": number;
    "changed_by": number;
    "email": string;
    "region": string;
    "city": string;
    "sponsor_code": string;
    "address_3": string;
    "address_2": string;
    "created_by": number;
    "sponsor_name": string;
    "user_id": number;
    "office_telephone": string
    "created_on": string;
    "website": string;
    "district": string;
    "extension": string;
    "sponsor_id": string;

}
