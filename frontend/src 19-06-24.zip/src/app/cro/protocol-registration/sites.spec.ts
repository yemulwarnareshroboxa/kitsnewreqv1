import { Sites } from './sites';

describe('Sites', () => {
  it('should create an instance', () => {
    expect(new Sites()).toBeTruthy();
  });
});
