import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitsnew',
  templateUrl: './kitsnew.component.html',
  styleUrls: ['./kitsnew.component.css']
})
export class KitsnewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
