import { Directive } from '@angular/core';

@Directive({
  selector: '[appInstructionsApp]'
})
export class InstructionsAppDirective {

  constructor() { }

}
