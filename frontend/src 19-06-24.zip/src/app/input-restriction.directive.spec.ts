import { InputRestrictionDirective } from './input-restriction.directive';
import { ElementRef } from '@angular/core';
describe('InputRestrictionDirective', () => {
  it('should create an instance', () => {
    const directive = new InputRestrictionDirective();
    expect(directive).toBeTruthy();
  });
});
