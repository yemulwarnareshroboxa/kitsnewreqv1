import { Protocol } from './protocol';

describe('Protocol', () => {
  it('should create an instance', () => {
    expect(new Protocol()).toBeTruthy();
  });
});
